package cl.duoc.eventtickets;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface TicketRepository extends JpaRepository<Ticket,String> {
 List<Ticket> findByUserIdOrderByCreatedAtDesc(String userId);
 List<Ticket> findByEventIdOrderByCreatedAtDesc(String eventId);
 List<Ticket> findByEventIdAndUserIdOrderByCreatedAtDesc(String eventId,String userId);
 long countByEventId(String eventId);
 long countByEventIdAndStatus(String eventId,String status);
}

package cl.duoc.eventtickets;
import jakarta.persistence.*;
import java.time.Instant;
@Entity
@Table(name="tickets", indexes={@Index(name="idx_ticket_event_user", columnList="eventId,userId")})
public class Ticket {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private String id;
 private String eventId; private String userId; private String holderName; private String eventName;
 private String status="GENERATED"; private String efsPath; private String s3Key;
 private Instant createdAt=Instant.now(); private Instant updatedAt=Instant.now();
 public String getId(){return id;} public void setId(String v){id=v;}
 public String getEventId(){return eventId;} public void setEventId(String v){eventId=v;}
 public String getUserId(){return userId;} public void setUserId(String v){userId=v;}
 public String getHolderName(){return holderName;} public void setHolderName(String v){holderName=v;}
 public String getEventName(){return eventName;} public void setEventName(String v){eventName=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
 public String getEfsPath(){return efsPath;} public void setEfsPath(String v){efsPath=v;}
 public String getS3Key(){return s3Key;} public void setS3Key(String v){s3Key=v;}
 public Instant getCreatedAt(){return createdAt;} public void setCreatedAt(Instant v){createdAt=v;}
 public Instant getUpdatedAt(){return updatedAt;} public void setUpdatedAt(Instant v){updatedAt=v;}
}

package cl.duoc.eventtickets;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.regions.Region;
@Configuration
public class AwsConfig {
 @Bean S3Client s3Client(@Value("${AWS_REGION:us-east-1}") String region){
  return S3Client.builder().region(Region.of(region)).build();
 }
}

package cl.duoc.eventtickets;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/tickets")
public class TicketController {
 private final TicketService service;
 public TicketController(TicketService service){this.service=service;}
 public record GenerateRequest(@NotBlank String eventId,@NotBlank String userId,@NotBlank String holderName,@NotBlank String eventName){}
 public record UpdateRequest(String holderName,String eventName){}
 @PostMapping public ResponseEntity<Ticket> generate(@Valid @RequestBody GenerateRequest r){return ResponseEntity.status(HttpStatus.CREATED).body(service.generate(r.eventId(),r.userId(),r.holderName(),r.eventName()));}
 @PostMapping("/{id}/upload") public Ticket upload(@PathVariable String id){return service.upload(id);}
 @GetMapping("/{id}/download") public ResponseEntity<byte[]> download(@PathVariable String id){
  byte[] data=service.download(id);return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
   .header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename= ticket-"+id+".pdf").body(data);
 }
 @PatchMapping("/{id}") public Ticket update(@PathVariable String id,@RequestBody UpdateRequest r){return service.update(id,r.holderName(),r.eventName());}
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable String id){service.delete(id);return ResponseEntity.noContent().build();}
 @GetMapping public List<Ticket> history(@RequestParam(required=false) String userId,@RequestParam(required=false) String eventId){return service.history(userId,eventId);}
 @GetMapping("/stats/{eventId}") public Map<String,Object> stats(@PathVariable String eventId){return service.stats(eventId);}
}

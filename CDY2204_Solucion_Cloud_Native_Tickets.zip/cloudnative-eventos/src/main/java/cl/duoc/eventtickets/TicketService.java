package cl.duoc.eventtickets;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import java.io.*;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

@Service
public class TicketService {
 private final TicketRepository repo; private final S3Client s3;
 @Value("${app.efs-path:/mnt/efs/tickets}") private String efsPath;
 @Value("${app.s3.bucket:}") private String bucket;
 public TicketService(TicketRepository repo,S3Client s3){this.repo=repo;this.s3=s3;}

 public Ticket generate(String eventId,String userId,String holderName,String eventName) {
  Ticket t=new Ticket(); t.setEventId(clean(eventId)); t.setUserId(clean(userId));
  t.setHolderName(holderName); t.setEventName(eventName);
  try {
   Path dir=Paths.get(efsPath,t.getEventId(),t.getUserId()); Files.createDirectories(dir);
   Path pdf=dir.resolve("ticket-"+UUID.randomUUID()+".pdf");
   createPdf(pdf,t); t.setEfsPath(pdf.toString()); t=repo.save(t);
   if(bucket!=null && !bucket.isBlank()) upload(t);
   return t;
  } catch(IOException e){throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"No se pudo generar ticket en EFS",e);}
 }
 public Ticket upload(String id){Ticket t=get(id);return upload(t);}
 private Ticket upload(Ticket t) {
  if(bucket==null || bucket.isBlank()) throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Configure APP_S3_BUCKET");
  try {
   String key=t.getEventId()+"/"+t.getUserId()+"/"+Paths.get(t.getEfsPath()).getFileName();
   s3.putObject(PutObjectRequest.builder().bucket(bucket).key(key).contentType("application/pdf").build(),RequestBody.fromFile(Paths.get(t.getEfsPath())));
   t.setS3Key(key);t.setStatus("UPLOADED");t.setUpdatedAt(Instant.now());return repo.save(t);
  } catch(Exception e){throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,"Error al subir ticket a S3",e);}
 }
 public byte[] download(String id) {
  Ticket t=get(id); if(t.getS3Key()==null) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"El ticket aún no está en S3");
  try {return s3.getObjectAsBytes(GetObjectRequest.builder().bucket(bucket).key(t.getS3Key()).build()).asByteArray();}
  catch(Exception e){throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,"No se pudo descargar desde S3",e);}
 }
 public Ticket update(String id,String holderName,String eventName) {
  Ticket t=get(id); if(holderName!=null)t.setHolderName(holderName); if(eventName!=null)t.setEventName(eventName);
  t.setUpdatedAt(Instant.now());
  try {createPdf(Paths.get(t.getEfsPath()),t); if(t.getS3Key()!=null) upload(t); return repo.save(t);}
  catch(IOException e){throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"No se pudo actualizar el PDF",e);}
 }
 public void delete(String id) {
  Ticket t=get(id);
  try {Files.deleteIfExists(Paths.get(t.getEfsPath()));}catch(IOException e){throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"No se pudo borrar archivo EFS",e);}
  if(t.getS3Key()!=null) s3.deleteObject(DeleteObjectRequest.builder().bucket(bucket).key(t.getS3Key()).build());
  repo.delete(t);
 }
 public List<Ticket> history(String userId,String eventId) {
  if(userId!=null && eventId!=null)return repo.findByEventIdAndUserIdOrderByCreatedAtDesc(eventId,userId);
  if(userId!=null)return repo.findByUserIdOrderByCreatedAtDesc(userId);
  if(eventId!=null)return repo.findByEventIdOrderByCreatedAtDesc(eventId);
  return repo.findAll();
 }
 public Map<String,Object> stats(String eventId) {
  long total=repo.countByEventId(eventId), uploaded=repo.countByEventIdAndStatus(eventId,"UPLOADED");
  return Map.of("eventId",eventId,"ticketsGenerated",total,"ticketsUploaded",uploaded,"pendingUpload",total-uploaded);
 }
 public Ticket get(String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Ticket no encontrado"));}
 private static String clean(String s){if(s==null||!s.matches("[a-zA-Z0-9_-]{1,80}"))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Identificador inválido");return s;}
 private void createPdf(Path path,Ticket t)throws IOException {
  try(PDDocument doc=new PDDocument()){
   PDPage page=new PDPage();doc.addPage(page);
   try(PDPageContentStream c=new PDPageContentStream(doc,page)){
    c.beginText();c.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD),18);c.newLineAtOffset(60,740);c.showText("TICKET DE EVENTO");c.endText();
    String[] lines={"Código: "+(t.getId()==null?"PENDIENTE":t.getId()),"Evento: "+safe(t.getEventName()),"ID evento: "+t.getEventId(),"Asistente: "+safe(t.getHolderName()),"Usuario: "+t.getUserId(),"Emitido: "+Instant.now()};
    int y=690;for(String line:lines){c.beginText();c.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA),12);c.newLineAtOffset(60,y);c.showText(line);c.endText();y-=28;}
   } doc.save(path.toFile());
  }
 }
 private String safe(String s){return s==null?"":s.replaceAll("[^\\p{Print}]","");}
}

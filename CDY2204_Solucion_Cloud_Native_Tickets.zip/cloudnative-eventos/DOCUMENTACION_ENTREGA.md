# Documento de entrega – CDY2204 Semana 3

## Nombre del proyecto
Sistema de Gestión de Reservas de Eventos con Tickets – Solución Cloud Native.

## Objetivo
Implementar un microservicio Spring Boot que permita gestionar tickets de eventos y demostrar integración con almacenamiento temporal EFS, almacenamiento de objetos S3 y despliegue continuo mediante Docker, Docker Hub, GitHub Actions y EC2.

## Desarrollo realizado
- Generación de ticket PDF personalizado con datos de evento y asistente.
- Almacenamiento temporal en EFS, organizado por evento y usuario.
- Carga automática a S3 al generar, cuando el bucket está configurado; endpoint de carga manual disponible.
- Descarga del PDF desde S3.
- Modificación de datos con regeneración del PDF y actualización del objeto S3.
- Eliminación del ticket en EFS, S3 y base de metadatos.
- Consulta de historial general o filtrado por usuario/evento.
- Estadísticas de tickets generados, subidos y pendientes por evento.
- Dockerfile y workflow GitHub Actions para publicar imagen y desplegar en EC2.

## Estructura de almacenamiento
EFS:
`/mnt/efs/tickets/{eventId}/{userId}/ticket-{uuid}.pdf`

S3:
` s3://{bucket}/{eventId}/{userId}/ticket-{uuid}.pdf`

## Matriz de trazabilidad
| Requisito de pauta | Implementación | Evidencia que debe capturarse |
|---|---|---|
| EFS (15) | `EFS_PATH` y volumen `/mnt/efs` | Directorios/archivo PDF dentro del EFS montado |
| Subida S3 (10) | `POST /api/tickets` y `POST /{id}/upload` | Objeto visible en bucket con prefijo evento/usuario |
| Modificar (15) | `PATCH /{id}` | Respuesta y PDF descargado con datos actualizados |
| Descargar (10) | `GET /{id}/download` | PDF recibido desde S3 |
| Historial (10) | `GET /api/tickets` con filtros | Respuesta JSON filtrada por usuario y evento |
| Pipeline (20) | `.github/workflows/deploy.yml` | Ejecución exitosa, imagen Docker Hub y contenedor EC2 |
| Video (20) | Guion README, sección 9 | Grabación Teams mostrando todas las funciones |

## Conclusión
La solución propuesta cubre funcionalmente los requerimientos descritos en la guía. La evaluación completa de los criterios de infraestructura y despliegue depende de ejecutar la configuración en una cuenta AWS real y presentar evidencias verificables. No se deben declarar como realizados los despliegues, pruebas o grabaciones que aún no se hayan ejecutado.

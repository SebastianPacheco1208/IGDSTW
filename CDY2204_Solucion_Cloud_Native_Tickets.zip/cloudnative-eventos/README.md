# Sistema de Gestión de Reservas de Eventos con Tickets
**Asignatura:** CDY2204 – Desarrollo Cloud Native, Semana 3  
**Solución de referencia:** Spring Boot + EFS + S3 + Docker + GitHub Actions + EC2

## 1. Descripción
Microservicio REST para generar tickets PDF personalizados, almacenarlos temporalmente en EFS, respaldarlos en S3 por evento/usuario, consultar historial, descargar, modificar, eliminar y consultar estadísticas.

## 2. Arquitectura
1. Cliente/Postman consume la API REST en el puerto 8080.
2. Spring Boot genera el PDF en el volumen EFS montado en `/mnt/efs/tickets/{eventId}/{userId}/`.
3. Cuando `APP_S3_BUCKET` está configurado, la generación sube automáticamente el PDF a S3. También existe endpoint explícito de carga.
4. La estructura S3 es `{eventId}/{userId}/{nombre-ticket}.pdf`.
5. GitHub Actions construye la imagen Docker, la publica en Docker Hub y se conecta por SSH a EC2 para reemplazar el contenedor.

**Persistencia:** H2 guarda metadatos del ticket. En despliegue se monta `/opt/event-tickets/data` para persistencia local de la base. Para alta disponibilidad se recomienda reemplazar H2 por RDS, fuera del alcance literal de esta pauta.

## 3. Requisitos previos
- Java 17 y Maven 3.9+ (para ejecución local).
- Docker.
- Cuenta AWS con bucket S3, sistema EFS y EC2 Linux.
- AWS CLI/credenciales para pruebas locales; en EC2 se recomienda IAM Instance Profile con permisos mínimos sobre el bucket.
- Repositorio GitHub y cuenta Docker Hub.

## 4. Ejecución local
```bash
mvn clean package
export AWS_REGION=us-east-1
export APP_S3_BUCKET=nombre-de-tu-bucket
export EFS_PATH=./data/efs
mkdir -p ./data/efs
java -jar target/event-tickets-1.0.0.jar
```
Si no se define `APP_S3_BUCKET`, generación y almacenamiento EFS funcionan, pero la carga/descarga S3 devuelve error de configuración. Para probar S3 local, configura credenciales AWS mediante el perfil estándar (`aws configure`) o variables de entorno.

Con Docker:
```bash
docker build -t duoc-event-tickets .
docker run --rm -p 8080:8080   -e AWS_REGION=us-east-1   -e APP_S3_BUCKET=nombre-de-tu-bucket   -v "$(pwd)/data/efs:/mnt/efs"   -v "$(pwd)/data/db:/app/data" duoc-event-tickets
```
En AWS, sustituye el volumen local por el montaje real de EFS.

## 5. Endpoints REST
| Método | Endpoint | Función |
|---|---|---|
| POST | `/api/tickets` | Genera PDF en EFS y lo sube automáticamente a S3 si está configurado |
| POST | `/api/tickets/{id}/upload` | Sube/reemplaza ticket en S3 |
| GET | `/api/tickets/{id}/download` | Descarga PDF desde S3 |
| PATCH | `/api/tickets/{id}` | Modifica datos y actualiza el PDF en EFS y S3 |
| DELETE | `/api/tickets/{id}` | Elimina objeto S3, archivo EFS y metadatos |
| GET | `/api/tickets?userId=usuarioX` | Historial filtrado por usuario |
| GET | `/api/tickets?eventId=evento123` | Historial filtrado por evento |
| GET | `/api/tickets/stats/{eventId}` | Estadísticas de tickets generados/subidos |

### Ejemplo de generación
```json
{
  "eventId": "evento123",
  "userId": "usuarioX",
  "holderName": "Camila Soto",
  "eventName": "Conferencia Cloud Native"
}
```
La respuesta contiene `id`, `efsPath`, `s3Key`, `status` y marcas de tiempo. Guarda el `id` para ejecutar el resto de las pruebas.

## 6. Configuración de AWS

### S3
1. Crea un bucket con nombre globalmente único y bloquea el acceso público.
2. Mantén cifrado por defecto (SSE-S3 o SSE-KMS).
3. Asigna a la instancia EC2 un IAM Instance Profile con permisos mínimos: `s3:PutObject`, `s3:GetObject`, `s3:DeleteObject` sobre `arn:aws:s3:::TU_BUCKET/*`. Agrega `s3:ListBucket` sobre el bucket si se requiere listar.
4. No guardes claves AWS en GitHub ni en el código.

### EFS
1. Crea un sistema EFS en la misma VPC de EC2.
2. Crea mount targets en las zonas de disponibilidad necesarias.
3. En el security group de EFS permite NFS TCP 2049 **solo desde el security group de EC2**.
4. Instala el cliente NFS en EC2 (por ejemplo `sudo apt-get install -y nfs-common` en Ubuntu o `sudo yum install -y amazon-efs-utils` en Amazon Linux, según la distribución).
5. Monta EFS y valida permisos:
```bash
sudo mkdir -p /mnt/efs
sudo mount -t nfs4 -o nfsvers=4.1 <EFS_DNS>:/ /mnt/efs
sudo mkdir -p /mnt/efs/tickets
sudo chmod 0775 /mnt/efs/tickets
```
Configura montaje persistente en `/etc/fstab` o usa EFS mount helper. El contenedor debe recibir `-v /mnt/efs:/mnt/efs`.

### EC2
- Instala Docker y habilita el servicio.
- Crea `/opt/event-tickets/data` y asigna permisos al usuario/contendor.
- Permite inbound TCP 8080 solo desde los orígenes necesarios (para producción, preferir HTTPS detrás de ALB/reverse proxy).
- Adjunta IAM Instance Profile a EC2; evita claves estáticas.

## 7. GitHub Actions y secretos
En GitHub: **Settings → Secrets and variables → Actions**, crea:
- `DOCKERHUB_USERNAME`
- `DOCKERHUB_TOKEN` (token de acceso Docker Hub, no contraseña)
- `EC2_HOST` (IP o DNS público)
- `EC2_USER` (por ejemplo `ubuntu` o `ec2-user`)
- `EC2_SSH_KEY` (clave privada SSH completa)
- `AWS_REGION`
- `APP_S3_BUCKET`

Al hacer push a `main`, el workflow `.github/workflows/deploy.yml` publica `usuario/duoc-event-tickets:latest` y despliega el contenedor en EC2. La instancia debe tener Docker, EFS montado y un IAM Instance Profile funcional antes de ejecutar el pipeline.

## 8. Pruebas con Postman
Importa `postman/Event-Tickets.postman_collection.json`. Orden sugerido:
1. Generar ticket.
2. Copiar `id` de la respuesta y pegarlo en la variable `ticketId`.
3. Consultar historial por usuario y evento.
4. Consultar estadísticas.
5. Descargar el PDF.
6. Modificar el ticket y volver a descargar para comprobar la actualización.
7. Eliminar el ticket y verificar que ya no aparece en el historial.

## 9. Guion sugerido para video
1. Presentar arquitectura y objetivo del sistema.
2. Mostrar variables y montaje EFS en EC2; explicar ruta temporal.
3. En Postman generar un ticket y mostrar el PDF/ruta en EFS.
4. Mostrar el objeto creado en S3 con ruta `evento/usuario/ticket.pdf`.
5. Ejecutar descarga, modificación, nueva descarga y eliminación.
6. Consultar historial por usuario y por evento.
7. Mostrar estadísticas.
8. Hacer push a `main`; enseñar ejecución exitosa de GitHub Actions, imagen en Docker Hub y contenedor actualizado en EC2.
9. Relacionar cada demostración con los criterios de la pauta.

## 10. Checklist de entrega
- [ ] Repositorio GitHub con el código fuente.
- [ ] Imagen Docker publicada en Docker Hub.
- [ ] EFS y S3 configurados en AWS.
- [ ] EC2 con contenedor desplegado.
- [ ] Pipeline GitHub Actions exitoso.
- [ ] Pruebas Postman ejecutadas y evidencias.
- [ ] Video de Teams con demostración completa.
- [ ] Este proyecto/documentación comprimidos en ZIP.

## 11. Consideraciones y límites
Este paquete entrega código y configuración de referencia. No crea recursos dentro de tu cuenta AWS, no publica la imagen en tu Docker Hub, no configura secretos en GitHub ni graba la reunión de Teams: esas acciones requieren tus cuentas, credenciales y participación. La configuración de red, IAM, DNS y montaje EFS debe validarse en tu entorno real antes de afirmar que el despliegue está operativo.
